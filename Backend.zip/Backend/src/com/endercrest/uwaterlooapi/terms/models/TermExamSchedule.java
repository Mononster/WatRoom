package com.endercrest.uwaterlooapi.terms.models;

import com.endercrest.uwaterlooapi.courses.models.CourseExamSchedule;

/**
 * Created by Thomas Cordua-von Specht on 12/2/2016.
 */
public class TermExamSchedule extends CourseExamSchedule {
}
