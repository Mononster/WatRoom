package com.endercrest.uwaterlooapi.terms.models;

/**
 * Created by Thomas Cordua-von Specht on 12/2/2016.
 *
 * TODO IMPLEMENT THIS MODEL. Will require a custom deserializer.
 */
public class TermList {
}
