package com.endercrest.uwaterlooapi.terms.models;

import com.endercrest.uwaterlooapi.base.models.UWInfoSession;

/**
 * Created by Thomas Cordua-von Specht on 12/4/2016.
 */
public class TermInfoSession extends UWInfoSession{

}
