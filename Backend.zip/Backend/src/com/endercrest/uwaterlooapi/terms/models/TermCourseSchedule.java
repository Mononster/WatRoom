package com.endercrest.uwaterlooapi.terms.models;

import com.endercrest.uwaterlooapi.courses.models.CourseSchedule;

/**
 * Created by Thomas Cordua-von Specht on 12/3/2016.
 */
public class TermCourseSchedule extends CourseSchedule {
}
