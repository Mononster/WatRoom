package com.endercrest.uwaterlooapi.exceptions;

/**
 * Created by Thomas Cordua-von Specht on 6/23/2017.
 */
public class NotImplementedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public NotImplementedException(){}
}
