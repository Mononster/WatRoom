package com.endercrest.uwaterlooapi.awards.models;

/**
 * Created by Thomas Cordua-von Specht on 12/1/2016.
 */
public class AwardGraduate extends AwardBase {

}
