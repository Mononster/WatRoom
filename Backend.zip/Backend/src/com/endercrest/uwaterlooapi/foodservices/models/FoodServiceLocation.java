package com.endercrest.uwaterlooapi.foodservices.models;

import com.endercrest.uwaterlooapi.base.models.UWLocation;

/**
 * Created by Thomas Cordua-von Specht on 11/27/2016.
 */
public class FoodServiceLocation extends UWLocation{

}
