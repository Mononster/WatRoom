package com.endercrest.uwaterlooapi.events.models;

/**
 * Created by Thomas Cordua-von Specht on 12/1/2016.
 */
public class EventHoliday {

    private String name;
    private String date;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
