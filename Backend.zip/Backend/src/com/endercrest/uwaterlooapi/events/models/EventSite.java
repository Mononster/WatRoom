package com.endercrest.uwaterlooapi.events.models;

/**
 * Created by Thomas Cordua-von Specht on 12/1/2016.
 */
public class EventSite extends EventBase {
}
