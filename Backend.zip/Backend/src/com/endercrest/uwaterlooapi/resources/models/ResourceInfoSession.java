package com.endercrest.uwaterlooapi.resources.models;

import com.endercrest.uwaterlooapi.base.models.UWInfoSession;

/**
 * Created by Thomas Cordua-von Specht on 12/5/2016.
 */
public class ResourceInfoSession extends UWInfoSession {
}
