package com.endercrest.uwaterlooapi.opportunities.models;

/**
 * Created by Thomas Cordua-von Specht on 12/1/2016.
 */
public class OpportunitySite extends OpportunityBase {

    private String site;

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }
}
